---
source: README.md
---

# Original: repository root README.md

(Full contents from repository)
